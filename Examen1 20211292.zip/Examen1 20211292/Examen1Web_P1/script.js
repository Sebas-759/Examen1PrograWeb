document.getElementById('edad').addEventListener("click")
let currentyear =  new Date().getFullYear();
let birthdate = (document.getElementById("birth").value).split("/").splice(0,2);
let edad = parseInt(currentyear)-parseInt(birthdate)
document.getElementById('age').innerHTML = edad
