document.getElementById("Peso").addEventListener("submit",calcularIMC)
function calcularIMC(event){
    event.preventDefault()
    let altura = parseFloat(document.getElementById("altura").innerHTML)
    let peso = parseFloat(document.getElementById("peso").innerHTML)
    let resultado = peso/(altura*altura)
    document.getElementById("resultado").innerHTML = "Su IMC es: " + resultado
    console.log(resultado)
}